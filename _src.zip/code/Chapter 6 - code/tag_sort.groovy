_doc.tags.values.size() > 0 ? _doc.tags.values[0] : '\u19999'
